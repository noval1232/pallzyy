<?php
require '../mainconfig.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta property="og:type" content="website" />
    <meta name="description" content="<?php echo $config['web']['meta']['description']; ?>" />
    <meta name="keywords" content="<?php echo $config['web']['meta']['keywords']; ?>" />
    <meta name="author" content="<?php echo $config['web']['meta']['author'] ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo $config['web']['title']; ?>" />
    <meta property="og:description" content="<?php echo $config['web']['meta']['description']; ?>" />
    <meta property="og:url" content="<?php echo $config['web']['base_url'] ?>" />
    <meta property="og:site_name" content="<?php echo $config['web']['title']; ?>" />

    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Landing | <?php echo $config['web']['title']; ?></title>

    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="icon" type="image/png" href="<?php echo $config['web']['base_url'] ?>assets/images/favicon.ico" />

    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="assets/css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="aos_next/dist/aos.css" />
    <script data-search-pseudo-elements defer src="assets/libs/font-awesome/5-11-2/js/all.min.js"></script>
    <script src="assets/libs/feather-icons/4-24-1/feather.min.js"></script>
</head>

<body>
    <div id="layoutDefault">
        <div id="layoutDefault_content">
            <main>
                <nav class="navbar navbar-marketing navbar-expand-lg bg-transparent navbar-dark fixed-top">
                    <div class="container">
                        <a class="navbar-brand text-white" href="javascript:void(0);"><?php echo $config['web']['title']; ?></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i data-feather="menu"></i>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto mr-lg-5">
                                <li class="nav-item"><a class="nav-link" href="#home">Beranda </a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo $config['web']['base_url'] ?>page/services">Daftar Harga </a></li>                               
                            </ul>
                            <a class="btn-teal btn rounded-pill px-4 ml-lg-4" href="<?php echo $config['web']['base_url'] ?>auth/register">Daftar<i class="fas fa-arrow-right ml-1"></i></a>
                        </div>
                    </div>
                </nav>
                <header class="page-header page-header-dark gd-primary">
                    <div class="page-header-content pt-10">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-6" data-aos="fade-up">
                                    <h1 class="page-header-title">
                                        <?php echo $config['web']['title']; ?>
                                        SMM PANEL INDONESIA
                                    </h1>
                                    <p class="page-header-text mb-5">
                                        menyediakan berbagai layanan social media marketing yang bergerak terutama di Indonesia. Dengan bergabung bersama kami, Anda dapat menjadi penyedia jasa social media atau reseller social media
                                        seperti jasa penambah Followers, Likes, dll.
                                    </p>
                                    <a class="btn btn-teal btn-marketing rounded-pill lift lift-sm" href="<?php echo $config['web']['base_url'] ?>auth/login">Login<i class="fas fa-arrow-right ml-1"></i></a>
                                    <a class="btn btn-teal btn-marketing rounded-pill lift lift-sm" href="<?php echo $config['web']['base_url'] ?>auth/register">Daftar<i class="fas fa-arrow-right ml-1"></i></a>
                                </div>
                                <div class="col-lg-6 d-none d-lg-block" data-aos="fade-up" data-aos-delay="50"><img class="img-fluid" src="assets/image/icon.svg" /></div>
                            </div>
                        </div>
                    </div>
                    <div class="svg-border-rounded text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 144.54 17.34" preserveAspectRatio="none" fill="currentColor">
                            <path d="M144.54,17.34H0V0H144.54ZM0,0S32.36,17.34,72.27,17.34,144.54,0,144.54,0" />
                        </svg>
                    </div>
                </header>
                <section class="bg-white py-10">
                    <div class="container">
                        <div class="row text-center">
                            <div class="col-lg-4 mb-5 mb-lg-0">
                                <div class="icon-stack icon-stack-xl gd-primary text-white mb-4"><i data-feather="layers"></i></div>
                                <h3>LAYANAN TERBAIK</h3>
                                <p class="mb-0">Layanan terbaik dan paling lengkap, Tersedia server Indonesia terbaik</p>
                            </div>
                            <div class="col-lg-4 mb-5 mb-lg-0">
                                <div class="icon-stack icon-stack-xl gd-primary text-white mb-4"><i data-feather="smartphone"></i></div>
                                <h3>PELAYANAN BANTUAN</h3>
                                <p class="mb-0">Bantuan Ramah dan Dukungan Komunitas. Layanan Termurah yang Bisa Anda dapatkan.</p>
                            </div>
                            <div class="col-lg-4">
                                <div class="icon-stack icon-stack-xl gd-primary text-white mb-4"><i data-feather="code"></i></div>
                                <h3>KEMUDAHAN PENGGUNAAN</h3>
                                <p class="mb-0">Penggunaan yang Mudah dan Tersedia berbagai pilihan Metode Pembayaran..</p>
                            </div>
                        </div>
                    </div>
                    <div class="svg-border-rounded text-light">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 144.54 17.34" preserveAspectRatio="none" fill="currentColor">
                            <path d="M144.54,17.34H0V0H144.54ZM0,0S32.36,17.34,72.27,17.34,144.54,0,144.54,0" />
                        </svg>
                    </div>
                </section>
                <hr class="m-0" />
                <section class="gd-primary py-10">
                    <div class="container">
                        <div class="row my-10">
                            <div class="col-lg-6 mb-5">
                                <div class="d-flex h-100">
                                    <div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-question"></i></div>
                                    <div class="ml-4">
                                        <h5 class="text-white">
                                            Apa Itu
                                            <?php echo $config['web']['title']; ?>?
                                        </h5>
                                        <p class="text-white-50">
                                            <?php echo $config['web']['title']; ?>
                                            adalah sebuah platform bisnis yang menyediakan berbagai layanan sosial media marketing yang bergerak terutama di Indonesia. Dengan bergabung bersama kami, Anda dapat menjadi penyedia jasa
                                            sosial media atau reseller sosial media seperti jasa penambah Followers, Likes, dll.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-5">
                                <div class="d-flex h-100">
                                    <div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-question"></i></div>
                                    <div class="ml-4">
                                        <h5 class="text-white">
                                            Bagaimana cara mendaftar di
                                            <?php echo $config['web']['title']; ?>?
                                        </h5>
                                        <p class="text-white-50">
                                            Anda dapat langsung mendaftar di website
                                            <?php echo $config['web']['title']; ?>
                                            pada halaman Daftar.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-5 mb-lg-0">
                                <div class="d-flex h-100">
                                    <div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-question"></i></div>
                                    <div class="ml-4">
                                        <h5 class="text-white">Bagaimana cara membuat pesanan??</h5>
                                        <p class="text-white-50">
                                            Untuk membuat pesanan sangatlah mudah, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman pemesanan dengan mengklik menu yang sudah tersedia. Selain itu Anda juga dapat
                                            melakukan pemesanan melalui request API bagi para pemilik web SMM.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="d-flex h-100">
                                    <div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-question"></i></div>
                                    <div class="ml-4">
                                        <h5 class="text-white">Bagaimana cara melakukan deposit/isi saldo?</h5>
                                        <p class="text-white-50">
                                            Untuk melakukan deposit/isi saldo, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman deposit dengan mengklik menu yang sudah tersedia. Kami menyediakan deposit melalui
                                            bank dan pulsa atau juga Dompet Digital.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </div>
        <div id="layoutDefault_footer">
            <footer class="footer pt-10 pb-5 mt-auto bg-dark footer-light">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-6 small">
                            Copyright &#xA9;
                            isi sendiri
                            <?php echo date( "Y"); ?>
                        </div>
                        <div class="col-md-6 text-md-right small">
                            <a href="javascript:void(0);">Privacy Policy</a>
                            &#xB7;
                            <a href="javascript:void(0);">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="assets/js/jquery-3.4.1.min.js"></script>
    <script src="assets/libs/bootstrap/4-3-1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script src="aos_next/dist/aos.js"></script>
    <script>
        AOS.init({
            disable: "mobile",
            duration: 600,
            once: true,
        });
    </script>
    <sb-customizer project="sb-ui-kit-pro"></sb-customizer>
</body>

</html>